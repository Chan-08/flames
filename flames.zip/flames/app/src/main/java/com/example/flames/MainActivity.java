package com.example.flames;



import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calculateFlames(View view) {
        EditText editTextPerson1 = findViewById(R.id.editTextPerson1);
        EditText editTextPerson2 = findViewById(R.id.editTextPerson2);
        TextView textViewResult = findViewById(R.id.textViewResult);

        String person1 = editTextPerson1.getText().toString().toLowerCase().trim();
        String person2 = editTextPerson2.getText().toString().toLowerCase().trim();

        if (TextUtils.isEmpty(person1) || TextUtils.isEmpty(person2)) {
            textViewResult.setText("Please enter both names.");
            return;
        }

        // Calculate Flames result
        String result = calculateResult(person1, person2);

        // Display result
        textViewResult.setText("Flames Result: " + result);
    }

    private String calculateResult(String person1, String person2) {
        // Remove common letters
        StringBuilder sb1 = new StringBuilder(person1);
        StringBuilder sb2 = new StringBuilder(person2);

        for (int i = 0; i < person1.length(); i++) {
            char c = person1.charAt(i);
            if (sb2.indexOf(String.valueOf(c)) != -1) {
                sb1.deleteCharAt(i);
                sb2.deleteCharAt(sb2.indexOf(String.valueOf(c)));
                i--; // Adjust the index after deletion
            }
        }

        // Count remaining letters
        int remainingLetters = sb1.length() + sb2.length();

        // Determine Flames result
        String flamesResult = "FLAMES";
        while (flamesResult.length() > 1) {
            int index = remainingLetters % flamesResult.length() - 1;
            if (index == -1) {
                index = flamesResult.length() - 1;
            }
            flamesResult = flamesResult.substring(0, index) + flamesResult.substring(index + 1);
        }

        return flamesResult;
    }
}
